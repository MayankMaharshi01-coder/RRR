import { useState } from 'react'
import Input from './Input'
import DropDown from './DropDown'
import { Icon } from "@iconify/react";
import Form from './Form'
import { useFormik } from 'formik'
import * as Yup from 'yup';
import { postThings } from './api'
import Textarea from './Textarea'
import FormButton from './FormButton'



function ProductUploadForm() {

const [focus, setFocus] = useState()

  const validationSchema = Yup.object({
    img: Yup.mixed().required('Image is required'),
    school: Yup.string().required('Title is required'),
    condition: Yup.string().oneOf(['good', 'avarage', 'nice'], 'Select a valid condition').required('Condition is required'),
    description: Yup.string().required('Description is required'),
    incharge: Yup.string().required('Incharge Name is required'),
    category: Yup.string().required('Category is required'),
    date: Yup.date().required('Date is required'),
  });


  const formik = useFormik({
    initialValues: {
      img: null,
      school: '',
      incharge: '',
      category: '',
      date: '',
      condition: 'condition',
      description: ''
    },
    validationSchema: validationSchema,
    onSubmit: values => {
      const data = new FormData();
      data.append('img', values.img);
      data.append('school', values.school);
      data.append('incharge', values.incharge);
      data.append('category', values.category);
      data.append('date', values.date);
      data.append('condition', values.condition);
      data.append('description', values.description);
      const promise = postThings(data);
      promise.then(responseData => {
        console.log('Response data after submission', responseData);
      })
      console.log('Form data', data);


    }
  })

    const handleFileChange = (event) => {
        formik.setFieldValue('img', event.currentTarget.files[0]);
    };


  return (
    <>
    <div className="bg-white  min-h-screen w-screen flex justify-center py-15 overflow-auto px-10">
      <Form onSubmit={formik.handleSubmit}>
        <h1 className='text-xl font-bold self-start text-black mb-6 border-b border-gray-300 w-full bg-[#D9E4DD] py-4 pl-8'>Upload Product Your Product</h1>
        <div className='bg-[#D9E4DD]
     inline-flex 
     w-screen
     flex-col
     md:w-[500px]
     lg:w-[600px]
     gap-6
     items-center
     px-8'>
        <Input type="file" touched={formik.touched.img} errors={formik.errors.img} id="img" name="img" value={formik.values.img} onChange={handleFileChange}>Upload Image</Input>
        <Input type="text" touched={formik.touched.school} errors={formik.errors.school} name="school" value={formik.values.school} onChange={formik.handleChange} onBlur={formik.handleBlur} placeholder=" ">School Name</Input>
        <Input type="text" touched={formik.touched.incharge} errors={formik.errors.incharge} name="incharge" value={formik.values.incharge} onChange={formik.handleChange} onBlur={formik.handleBlur} placeholder=" ">Incharge Name</Input>
        <Input type="text" touched={formik.touched.category} errors={formik.errors.category} name="category" value={formik.values.category} onChange={formik.handleChange} onBlur={formik.handleBlur} placeholder=" ">Product Category</Input>
        <Input type="date" touched={formik.touched.date} errors={formik.errors.date} name="date" value={formik.values.date} onChange={formik.handleChange} onBlur={formik.handleBlur} placeholder=" ">Date</Input>
        <DropDown name="condition" label="Condition" useFor="form" touched={formik.touched.condition} errors={formik.errors.condition} value={formik.values.condition} onChange={formik.handleChange}>
          <option selected disabled className=" disabled:text-gray-200 bg-green-900" value="condition">Product Condition</option>
          <option  className="bg-green-900"  value="good">Good</option>
          <option  className="bg-green-900"  value="avarage">Avarage</option>
          <option  className="bg-green-900"  value="nice">Nice</option>
        </DropDown>
      

   <Textarea touched={formik.touched.description} errors={formik.errors.description} name="description" value={formik.values.description} onChange={formik.handleChange} onBlur={formik.handleBlur}>Description</Textarea>
     <FormButton formik={formik}>Upload Product</FormButton>
      </div>
      </Form>
      </div>
    </>
  )
}

export default ProductUploadForm;
