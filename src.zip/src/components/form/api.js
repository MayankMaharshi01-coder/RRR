import axios from "axios";

export function postThings(data) {
return axios.post('http://localhost:3000/things', data).then(response => {
    console.log('API response',response.data);
    return response.data;
}).catch(error => {
    console.error('API error', error);
    throw error;
});
}

export function getThings() {
return axios.get('http://localhost:3000/things').then(response => {
    console.log('API response',response.data);
    return response.data;
}).catch(error => {
    console.error('API error', error);
    throw error;
});
}