import React from "react";
import Form from "./Form";
import Input from "./Input";
import { useFormik } from 'formik'
import * as Yup from 'yup';
import FormButton from "./FormButton";

function SchoolRegisterForm() {
    const validationSchema = Yup.object({
        schoolName: Yup.string().required('School Name is required'),
        inchargeName: Yup.string().required('Incharge Name is required'),
      });

      const formik = useFormik({
        initialValues: {
          schoolName: '',
          inchargeName: ''
        },
        validationSchema: validationSchema,
        onSubmit: values => {
          console.log('Form data', values);
        }
      });


return(<div className="bg-white  min-h-screen w-full flex justify-center py-30 overflow-auto px-10">
    <Form>
    <h1 className='text-xl font-bold self-start text-black mb-6 border-b border-gray-300 w-full bg-white py-4 pl-8'>School Registration Form</h1>
    <div className="bg-white
     inline-flex 
     w-screen
     flex-col
     md:w-[500px]
     lg:w-[600px]
     gap-6
     items-center
     px-8">
    <Input type="text" name="schoolName" placeholder=" " value={formik.values.schoolName} onChange={formik.handleChange} onBlur={formik.handleBlur} errors={formik.errors.schoolName} touched={formik.touched.schoolName}>School Name</Input>
    <Input type="text" name="inchargeName" placeholder=" " value={formik.values.inchargeName} onChange={formik.handleChange} onBlur={formik.handleBlur} errors={formik.errors.inchargeName} touched={formik.touched.inchargeName}>Incharge Name</Input>
    <FormButton formik={formik}>Register</FormButton>
    </div>
    </Form>
</div>)
};

export default SchoolRegisterForm;