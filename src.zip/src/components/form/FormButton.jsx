import React from "react";

function FormButton({children, formik}) {
return(
        <button className='bg-green-800 text-xl px-10 py-2 text-white border-secondary border rounded-[9px] self-center mt-2 transition-all duration-700 hover:bg-white hover:text-green-800 hover:duration-700 hover:transition-all  disabled:bg-green-100 disabled:text-gray-200 disabled:border-green-200 disabled:cursor-not-allowed' type='submit' disabled={formik.isValid !== false && formik.dirty !== false ? false : true}>{children}</button>)
};

export default FormButton;