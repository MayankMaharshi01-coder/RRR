import React from "react";

function Textarea({touched, errors, onChange, value, name, children, onBlur}) {
return(<>
<div className='flex flex-col items-start  w-full relative  min-w-[200px]'>
        
        <textarea name={name} placeholder=' ' value={value} onChange={onChange} onBlur={onBlur} className="peer h-full min-h-[100px] w-full resize-none rounded-[7px] border border-white not-placeholder-shown:border-t-transparent ring-green-500 bg-transparent px-3 py-2.5 font-sans text-sm font-normal text-white outline-0 transition-all placeholder-shown:border placeholder-shown:border-white placeholder-shown:border-t-white focus:border focus:border-green-500 focus:ring-2 focus:ring-green-500 focus:outline-green-500 focus:outline-0 disabled:resize-none disabled:border-0 disabled:bg-blue-gray-50"></textarea>
        <label className="
        pointer-events-none 
        absolute  
        bg-[#D9E4DD]
        left-4 
        top-5
        translate-y-3 
        flex   
        select-none 
        text-[11px]  
      
        text-white
        font-semibold
        transition-all 
        peer-placeholder-shown:text-sm 
        peer-placeholder-shown:-top-2
        peer-placeholder-shown:text-white 
        peer-focus:text-[11px] peer-focus:leading-tight 
        peer-focus:text-white
      
        peer-disabled:text-transparent 
        peer-disabled:peer-placeholder-shown:text-white">{children}</label>
        </div>
        {touched && errors ? (
              <span className="text-red-500 text-[12px] self-start ml-3 -mt-5">* {errors}</span>
            ) : null}
        </>)
};

export default Textarea;